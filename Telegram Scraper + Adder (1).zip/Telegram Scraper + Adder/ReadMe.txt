Hello !!!!!, 

How its works?????

- you must install Python 3
- Install Atom or any text editor (Not necessary )
- Install telethon using cmd  command: pip3 install telethon\
-Get your Api and Hash id from www.my.telegram.org/auth
-add detials to scrapper.py and adder.py
-Run scrapper.py and scrap group members.
-Run adder.py and add scrapped members to your group


Basically it scrapes member from group where the logined id is admin and it creates a .csv file.
And the adder reads .csv file and add member to the target group.





  ____                                    ____ _           _    _         
 / ___|  __ _ _ __ ___   ___  ___ _ __   / ___| |__   ___ | | _| |_   _  
 \___ \ / _` | '_ ` _ \ / _ \/ _ \ '__| | |   | '_ \ / _ \| |/ / | | |    
  ___) | (_| | | | | | |  __/  __/ |    | |___| | | | (_) |   <| | |_| |  
 |____/ \__,_|_| |_| |_|\___|\___|_|     \____|_| |_|\___/|_|\_\_|\__, |  
                                                                   |___/  
